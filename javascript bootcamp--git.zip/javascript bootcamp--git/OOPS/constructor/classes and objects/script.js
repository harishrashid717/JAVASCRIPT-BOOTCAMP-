class admission {
    constructor(name, mobileNo, money){
        this.name = name;
        this.mobileNo = mobileNo;
        this.money = money;
    }

    enrolled(){
        alert(`${this.name}, you have sucessfully enrolled`);
    }

    notEnrolled() {
        alert(`${this.name}, your admission is declined because you have not met the criteria `);
    }
}

let harish = new admission("harish", 328749283, 4235);
console.log(harish.enrolled());