class car{
    constructor(brand, wheels, colour ){
        this.brand = brand;
        this.wheels = wheels;
        this.colour = colour;

    }

     info(){
        console.log(`car brand-- ${this.brand}, colour -- ${this.colour}, no of wheels ${this.wheels}`);
    }
     static hello (){
        console.log("hello ");
    }
}

let bmw = new car("BMW", 4, "black");
// console.log(bmw.info());

class truck extends car{
    constructor(brand, wheels, colour){
        super(brand, wheels, colour);
        
    }
    info(){
        console.log("this will show you information about the car");
        super.info();;
    }

}

let mahindra = new truck("mahindra", 3, "brown");
console.log(mahindra.info());
// console.log(mahindra.hello()); this will throw an error because hello is static and we can't access the static method from the parent class  