function user(username, age, isLogin){
    this.username = username ;
    this.age = age;
    this.isLogin = isLogin;
    return this;
}

let user1 = new user("harish", 22, true);
console.log(user1);