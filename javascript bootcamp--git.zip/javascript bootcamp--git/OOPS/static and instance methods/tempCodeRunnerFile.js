static capitalize (name){
    //     return name.charAt(0).toUpperCase() + name.substr(1, name.length);
    // }