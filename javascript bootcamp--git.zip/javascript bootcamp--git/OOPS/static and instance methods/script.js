// class mathHelper{
//     static add (a, b){
//         return (a+b);
//     }

//     multiply(a, b){
//         return (a*b);
//     }
// }

// console.log(mathHelper.add(2,3));
// // console.log(mathHelper.multiply(2,3)); it will give an error because it's not static

// let num = new mathHelper();
// console.log(num.multiply(2, 3));

class animal {

    constructor(name){
        this.name = animal.capitalize(name);
    }

    static capitalize (name){
        return name.charAt(0).toUpperCase() + name.substr(1, name.length);
    }

    speak(){
        console.log(`${this.name} is a animal`);
    }

}

// let dog = animal("tommy");
// dog.speak();
let tommy = new animal("tommy");
tommy.speak();