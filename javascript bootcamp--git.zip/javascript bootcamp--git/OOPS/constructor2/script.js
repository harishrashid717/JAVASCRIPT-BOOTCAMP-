class employee {
    constructor(firstName){
        this.firstName = firstName;
    }
    login(){
        console.log(`${this.firstName} has logged in`);
    }
    logout(){
        console.log("you have logged out");
    }
    leave(days){
        console.log(`your leave is granted for ${days}`);
         
    }
}

class programmer extends employee{
    constructor(lastName, firstName){
        super(firstName);
        this.firstName = firstName;
        this.lastName = lastName;
    }
    leave(days){
        super.leave(days);
        console.log("you are progr  ammer then one extra for you, now " , (days+1));

     

    }

}

let harish = new programmer("rahsid", "harish");
harish.login()
harish.leave(4);