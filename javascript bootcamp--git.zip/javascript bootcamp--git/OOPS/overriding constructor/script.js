class Animal {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }

    speak() {
        console.log(`${this.name} makes a sound`);
    }
    displayAge(){
        console.log(`${this.name} is ${this.age} years old `);

    }
}

class Dog extends Animal {
    constructor(name, breed, age) {

        /*it's a good practice to call super() to ensure that the superclass's 
        constructor is executed, setting up any necessary properties or 
        performing other initialization tasks defined in the superclass. 
        */
        super(name, age);
        this.breed = breed;
    }

    bark() {
        console.log(`${this.name} barks`);
    }

    // Override the speak method from the superclass
    speak() {
        console.log(`${this.name} barks loudly`);
    }

}

// Create an instance of the subclass
const myDog = new Dog('Buddy', 'Golden Retriever', 12);


myDog.speak(); 
myDog.bark();  
myDog.displayAge();