let tagName1 = document.getElementsByTagName("h1");
console.log(tagName1.tagName);
console.dir(tagName1);