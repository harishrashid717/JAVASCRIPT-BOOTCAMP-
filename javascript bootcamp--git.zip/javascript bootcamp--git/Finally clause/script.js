foo =()=>{
    
try{

    console.log("I try sucessfully executed");
    return;
    zv
}
catch(error){
    console.log("I am in the error block and I will give an error");
    throw new Error("oops Error occured");
}
finally{

    console.log("Koi baat nahi ...!");
}

}
foo();  
console.log("Ending here");