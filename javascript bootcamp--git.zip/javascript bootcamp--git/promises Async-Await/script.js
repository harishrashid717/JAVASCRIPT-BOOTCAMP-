async function weatherControlRoom(){
    let delhiWeather = new Promise((resolve, reject)=>{
        setTimeout(()=>{
            resolve("29 deg");
        }, 8000)
    })
    console.log("delhi weather is fetching...");
    let delhiW = await delhiWeather;
    console.log("delhi weather is " + delhiW);
    let mumbaiWeather = new Promise((resolve, reject)=>{
        setTimeout(()=>{
            resolve("22 deg");
        }, 5000)
    })
    console.log("mumbai weather is fetching...");
    let mumbaiW = await mumbaiWeather;
    console.log("mumbai weather is fetched " + mumbaiW);

    return [delhiW, mumbaiW];
}   
// let harry = async() =>{
//     console.log("i will execute later");
// }
// console.log("execute me ");
// let main1 = async() =>{
//     let report = await weatherControlRoom();
//     let haris = await harry();
//     return [report, haris]
// }
// console.log(main1());

async function main1() {
    try {
      let result = await weatherControlRoom();
      console.log(result);
    } catch (error) {
      console.error("Error:", error);
    } finally {
        console.log("All the code ran successfully");
      }
  }
  
  console.log("execute me");
  main1();
  