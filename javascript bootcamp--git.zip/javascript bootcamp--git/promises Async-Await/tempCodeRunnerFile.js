let harry = async() =>{
//     console.log("i will execute later");
// }
// console.log("execute me ");
// let main1 = async() =>{
//     let report = await weatherControlRoom();
//     let haris = await harry();
//     return [report, haris]
// }
// console.log(main1());