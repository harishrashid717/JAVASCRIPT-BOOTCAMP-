async function example() {
    const result = await 'Hello, I am not a Promise'; // This value will be automatically wrapped in a resolved Promise
    console.log(result instanceof Promise);
  }
  
  example();
  