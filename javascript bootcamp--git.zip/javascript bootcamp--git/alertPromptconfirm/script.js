alert("Enter the value of a ");
let a = prompt("enter the value here ");
a = Number.parseInt(a);
console.log(typeof(a));
let typeOfDiv = document.getElementsByClassName('typeOf')[0];
// alert(typeOf(a));
// let datatype = typeOf(a);
let result = confirm("are you sure to check the datatype of the variable");
if(result){
    typeOfDiv.innerHTML  += typeof a;
}

// alert("Enter the value of a ");
//         let a = prompt("enter the value here ");
//         a = Number.parseInt(a);
//         const typeOfDiv = document.querySelector('.typeOf'); // Select the element
//         typeOfDiv.innerHTML += typeof a; // Append the type to the element's content