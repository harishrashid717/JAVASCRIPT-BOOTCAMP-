// promise chaning

let promise = new Promise((resolve, reject)=>{
    setTimeout(()=>{
        resolve("1st promise executed");
        // reject("1st promise rejected");
    }, 2000)
})

promise.then((value)=>{
    // document.write(value);
    console.log(value);

    let secondPromise = new Promise((resolve , reject)=>{
        setTimeout(()=>{
            // resolve("2nd promise executed");
            reject("second promise failed")
        }, 2000)
    })

    return secondPromise;
}).then((value)=>{
    // document.write(value);
    console.log(value);
    return 67;
}).catch((value)=>{
    // document.write(value);
    console.log(value);
})