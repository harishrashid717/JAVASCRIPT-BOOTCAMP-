const fetchData = () => {
    return new Promise((resolve, reject) => {
      // Simulating an asynchronous operation
      setTimeout(() => {
        const data = Math.random();
  
        if (data > 0.5) {
          resolve(data); // Fulfill the Promise with data
        } else {
          reject('Data value too low'); // Reject the Promise with an error message
        }
      }, 1000);
    });
  };
  
  fetchData()
    .then(result => {
      console.log('Fulfilled with:', result);
      return result * 2; // Returning a value to be used in the next .then() handler
    })
    .then(updatedResult => {
      console.log('Updated result:', updatedResult);
      // You can return another Promise here if needed
      // This returned value will be handled by the next .then() in the chain
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve('Another asynchronous operation');
        }, 1000);
      });
    })
    .then(message => {
      console.log('Final message:', message);
    })
    .catch(error => {
      console.error('Rejected with:', error);
    });
  