// let ele = document.getElementsByClassName("iteams")[0];
// ele.style.color="red";
// document.getElementsByClassName("navlist")[0].lastElementChild.style.color="yellow"

// document.getElementsByClassName("container")[0].firstElementChild.style.background="red"
// document.getElementsByClassName("container")[0].lastElementChild.style.background="red"

const navList = document.getElementsByClassName("navlist")[0];
let childNodes = Array.from(navList.childNodes);
console.log(childNodes);
console.log(navList.firstElementChild.nextElementSibling);

let a = document.body.firstChild;
let b = a.parentElement;
console.log(b);