const jokes = [`Why can’t you send a duck to space?
Because the bill would be astronomical!`,

`What does Jeff Bezos do before he goes to sleep?
He puts his PJ-Amazon!`,

`What happened when the world's tongue-twister champion got arrested?
They gave him a tough sentence!`,

`What did the mama cow say to the calf?
It’s pasture bedtime!`,

`How does a vampire start a letter?
Tomb it may concern!`,

`What do you call an illegally parked frog?
Toad!`,

`What did one plate say to the other?
Dinner is on me!`,

`Why do hummingbirds hum?
Because they don’t know the words!`,

`What do sprinters eat before a race?
Nothing. They fast!`,

`Two muffins are baking in an oven. One of them looks to the other and says, "Phew, it's getting hot in here!" The other looks back and says, "Ack! A talking muffin!"
`,
`Animal Jokes for Kids
best jokes for kids
What do cats eat for breakfast?
Mice Crispies!`,

`What do you call an elephant that doesn’t matter?
An irrelephant!`,

`What do you get when you cross a rabbit with shellfish?
An oyster bunny!`,

`Where do polar bears keep their money?
In a snow bank!`,

`Why did the pony get sent to his room?
He wouldn’t stop horsing around!`,

`What kind of dog does a magician have?
A Labracadabrador!`,

`Where do cows go on Friday nights?
They go to the moo-vies!`,

`Why couldn't the pony sing “Happy Birthday?”
Because she was just a little hoarse!`,

`How do you make an octopus laugh?
With ten-tickles!`,

`How do you keep a bull from charging?
Take away its credit card!`,

`Why can’t a leopard hide?
Because he’s always spotted!
 - Continue Reading Below
jokes for kids
What do frogs order at fast-food restaurants?
French flies!`,

`What do you get from a pampered cow?
Spoiled milk!`,

`What do you call an alligator who solves mysteries?
An investigator!`,

`Why is a snake difficult to fool?
You can’t pull its leg!`,

`What kind of socks do grizzlies wear?
None, they have bear feet!`,

`What do you get when you cross a snail with a porcupine?
A slowpoke!`,

`What did the dog say when it sat on sandpaper?
"Ruff!"`,

`What's a cat's favorite dessert?
Chocolate mouse!`,

`What fish only swims at night?
Starfish!`,

`What does a triceratops sit on?
Its tricera-bottom!`,

`Knock Knock Jokes for Kids
jokes for kids
Knock, knock.
Who’s there?
Weekend.
Weekend who?
Weekend do anything we want!`,

`Knock, knock.
Who’s there?
Figs.
Figs who?
Figs the doorbell, I’ve been knocking forever!`,

`Knock, knock.
Who’s there
Theodore.
Theodore who?
Theodore wasn’t opened so I knocked!`,

`Knock, knock.
Who’s there
Tank.
Tank who?
You’re welcome!`,

`Knock, knock.
Who’s there
Isabel.
Isabel who?
Isabel not working?`,

`Knock, knock.
Who’s there
Ice cream.
Ice cream who?
ICE CREAM SO YOU CAN HEAR ME!`,

`Knock, knock.
Who’s there
Icy.
Icy who?
Icy you in there!`,

`Knock, knock.
Who’s there
Dozen.
Dozen who?
Dozen anyone want to let me in?`,

`Knock, knock.
Who’s there
Scold.
Scold who?
Scold outside, let me in!`,

`Knock, knock.
Who’s there
Water.
Water who?
Water you asking so many questions for, just open up!`,

`Knock, knock.
Who’s there
Cargo.
Cargo who?
Car go, “Toot toot, vroom, vroom!”`,

`50 best jokes for kids
Knock, knock
Who’s there?
Hatch.
Hatch who?
Bless you!`,

`Knock, knock.
Who’s there
Annie.
Annie who?
Annie body home?`,

`Knock, knock.
Who’s there
Boo.
Boo who?
Don’t cry, it’s just a joke!`,

`Knock, knock.
Who’s there
Lettuce.
Lettuce who?
Lettuce in, it’s cold out here!`,

`Knock, knock.
Who’s there
An interrupting cow.
An interrupt—
MOO!`,

`Knock, knock.
Who’s there
Owls go.
Owls go who?
That’s right!`,
]

let min = 0; 
let max = jokes.length;

let jokeIndex = Math.floor(Math.random() * (max - min)) + min;
// console.log(jokeIndex);
let joke = document.getElementById("joke");
joke.innerHTML = jokes[jokeIndex];