let str = "harish";
str[2] = 'z';
console.log(str);