// let a = document.getElementsByTagName('div')[0];
// a.innerHTML = a.innerHTML + "<h1> this is my name </h1>";

let a = document.getElementsByTagName('div')[0];

// creation of a new div

let newDiv = document.createElement("div");
newDiv.innerHTML = "<h1> Hello World </h1>";
a.prepend(newDiv);