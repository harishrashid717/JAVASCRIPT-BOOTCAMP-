let first = document.getElementsByClassName("first")[0];
first.innerHTML= first.innerHTML + '<h1>I am inside of the first</h1>'

// creating a new element 
let div = document.createElement('div');
div.innerHTML = div.innerHTML + '<h2> it\'s a new div</h2>' + '<p>here is the paragraph</p>'
first.appendChild(div);
let firstID = document.getElementById('firstID');
let name = firstID.className;
name = "firstClass";
console.log(name);