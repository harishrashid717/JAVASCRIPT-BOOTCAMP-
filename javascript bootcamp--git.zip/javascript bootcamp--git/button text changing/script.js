let btn = document.getElementById("myButton");
let isOn = true;

function toggleButtonText() {
    if (isOn) {
        btn.innerText = "Off";
    } else {
        btn.innerText = "On";
    }
    isOn = !isOn;
}

btn.addEventListener('click', toggleButtonText);
