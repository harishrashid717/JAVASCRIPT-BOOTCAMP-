let arr= [1, 2, 4];
let obj = {... arr};
console.log(obj);

// passing the value to the function 
function add(a, b, c) {
    return a+b+c;
}

console.log(add(...arr));

let info = {
    name : "harish ", 
    age : 22, 
    isLogin : true
}

info = {...info, name : "faishal rashid"};
console.log(info);