let user = {
    name : "harish", 
    isLogin : true,
    loginCount : 12
}
console.log(user);

// making prototype 
let action = {
    run : ()=>{
        console.log("i am runing ");
    }
}
user.__proto__ = action;
action.__proto__ = {
    age : 22
}
user.run()
console.log(user.age);