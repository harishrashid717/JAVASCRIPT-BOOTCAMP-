// const currentDate = new Date();
// console.log(currentDate);
// console.log(currentDate.toString());   
// console.log(currentDate.toDateString());
// console.log(currentDate.toLocaleString());   

//   let newDate = new Date("2023-09-21");
//   console.log(newDate.toLocaleString());  

// let currentTimeStamp = Date.now();
// console.log(currentTimeStamp);

// function performHeavyComputation() {
//     // Simulate heavy computations by doing a large loop
//     for (let i = 0; i  < 100000000; i++) {
//       Math.sqrt(i);
//     }
//   }

//   const start = Date.now();
//   performHeavyComputation();
//   const end = Date.now();

//   let requiredTime = end - start;
//   console.log("the time required is " + requiredTime);

let newDate = new Date();
let h = newDate.getHours();
let m = newDate.getMinutes();
let s = newDate.getSeconds();
console.log(h);
console.log(m);
console.log(s);