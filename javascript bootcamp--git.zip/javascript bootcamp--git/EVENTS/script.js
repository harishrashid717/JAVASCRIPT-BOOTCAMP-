let a = document.getElementsByClassName("container")[0];

a.onclick = () =>{
    console.log("hello world");
    a.textContent = "harish programmer"
}

let butn = document.getElementById("btn");

let h = (eventObject)=>{
    alert("hello world1")
    console.log(eventObject.target);
    console.log(eventObject.type);
    console.log(eventObject.currentTarget);
    console.log(eventObject.clientX, eventObject.clientY);
}

let y = ()=>{
    alert("hello world2")
}

butn.addEventListener("click", h)

butn.addEventListener("click" , y)

// we can directly add event listner without using "let butn = document.getElementById("btn"); " and with using class or id name 

butn.removeEventListener("click", y)

let self = document.getElementsByClassName("myself")[0];
// self.onmouseover =()=>{
//     alert("my name is harish rashid")
// }
