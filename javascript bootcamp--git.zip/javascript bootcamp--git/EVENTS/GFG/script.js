let btn = document.getElementById("btn");
function displayMsg(){
    alert("hi I am harish rashid");
}
btn.addEventListener('click', displayMsg);

// changing the backgroud of input field 
let a =0, b= 0 , c = 10;
let inp = document.getElementById('inp');
function changeBackgroud(){
    inp.style.background = 'rgb(' + a + ',' + b + ',' + c + ')';

    a += 100;
    b += a+50;
    c += b+70;

    if(a>255) a-=b;
    if(b>255) b=a;
    if(c>255) c=b;
}
inp.addEventListener('keyup', changeBackgroud);