let butn = document.getElementsByClassName("btn")[0];

let clr = () => {
    alert("red color")
}

let dish = () =>{
    alert("briyani")
}

butn.addEventListener("click", clr);
butn.addEventListener("click", dish);

let google = document.getElementById("google");
let fb = document.getElementById("fb");
let twitter = document.getElementById("twitter");       

document.getElementById("google").addEventListener("click", ()=>{
    window.location("https://www.google.com/");

})

let bulb = document.getElementsByClassName("bulb")[0];
let bulbBtn = document.getElementById("bulb-btn");

bulbBtn.addEventListener('click', ()=>{
    bulb.classList.toggle("glow")
})

let isToggled = false;

bulbBtn.addEventListener('click', ()=>{
    if(isToggled){
        bulbBtn.innerText = "glow"
    }
    else{
        bulbBtn.innerText = "dark"
    }

    isToggled = !isToggled;
});