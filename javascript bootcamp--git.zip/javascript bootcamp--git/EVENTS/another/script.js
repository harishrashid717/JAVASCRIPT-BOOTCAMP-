let ele = document.getElementsByClassName("container")[0];

ele.onmouseenter=()=>{
    alert("hello ")
    let b= document.getElementsByClassName("container")[0];
    ele.innerHTML = "harish rashid"
}