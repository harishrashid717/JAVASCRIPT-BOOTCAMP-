let num = prompt("enter 1 to not get the value of first name ");
num = Number.parseInt(num);

let a = () =>{
    alert("harish")
}
let b = () =>{
    alert("rashid")
}

let name = document.getElementById('name');

name.addEventListener("click",a);  
name.addEventListener("click", b);

if (num=="1"){
    name.removeEventListener('click', a);
}   