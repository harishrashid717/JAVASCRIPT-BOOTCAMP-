let button = document.getElementById("btn");
let isEnabled = false;

function handleClick() {
    console.log("Button clicked!");
}

function toggleEvent() {
    if (isEnabled) {
        button.removeEventListener("click", handleClick);
    } else {
        button.addEventListener("click", handleClick);
    }
    // isEnabled = !isEnabled;
    console.log(isEnabled);
}

// Initial state: Event listener is not attached
toggleEvent();


// let btn = document.getElementById("btn");
// btn.onclick =()=>{
//     btn.textContent = "harish programmer"
// }

// let eventAdd = ()=>{
//     btn.textContent = "harish programmer";
// }
// let eventRemove = ()=>{
//     btn.textContent = "click me";
// }
// let state = true;

// btn.addEventListener('click', ()=>{
//     if(state){
//         eventAdd();
//     }
//     else{
//         // eventRemove();
//         // btn.removeEventListener('click', eventAdd())
//     }
//     state = !state;
//     console.log(state);
// })

    // btn.onclick = ()=>{
    //     if(state){
    //         btn.addEventListener('click', eventAdd())
    //     }
    //     else{
    //         btn.removeEventListener('click', eventAdd());
    //     }

    //     state = !state;
    // }

//  let textToggle = () =>{
//     if (state) {
//         btn.innerText = "harish progmammer";
//         btn.removeEventListener('click', textToggle);
//     }
//     state = !state;
//  }
//  btn.addEventListener('click', textToggle);
