let a=()=>{
return new Promise((resolve, reject)=>{
    setTimeout(()=>{
        resolve(432);
    }, 3000)
})
}

(async ()=>{
    let x = await a();
    console.log(x);
    let y = await a();
    console.log(y);
    let z = await a();
    console.log(z);
})();
