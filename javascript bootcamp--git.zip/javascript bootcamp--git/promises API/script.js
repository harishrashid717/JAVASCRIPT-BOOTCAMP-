randomNo = () =>{
    let min = 1000;
    let max = 5000;

    let num = Math.floor( Math.random()*(max-min))+min;
    
    return num;

}
console.log(typeof randomNo());
let p1 = new Promise((resolve, reject)=>{
    setTimeout(()=>{
    resolve("process 1 is executed")
    }, randomNo())
});

let p2 = new Promise((resolve, reject)=>{
    setTimeout(()=>{
        
        reject("process 2 can't be executed");
        // reject(new Error("process 2 can't be executed"));
        }, randomNo())
});

let p3 = new Promise((resolve, reject)=>{
    setTimeout(()=>{
        resolve("process 3 is executed")
        }, randomNo())
})

p1.then((value)=>{
    console.log(value);
})
p2.catch((value)=>{
    console.log(value);
})
p3.then((value)=>{
    console.log(value); 
})

// let promise_all = Promise.all([p1, p2, p3]);    
// promise_all.then((value)=>{
//     console.log(value);
// });

// let allSetellled = Promise.allSettled([p1, p2, p3]);
// allSetellled.then ((value)=>{
//     console.log(value);
// })

let promiseRace = Promise.race([p1, p2, p3]);
promiseRace.then((value)=>{
    console.log(value);
})

