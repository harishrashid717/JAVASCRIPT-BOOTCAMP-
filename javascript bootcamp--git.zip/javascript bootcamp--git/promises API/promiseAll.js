// random generate 
const randomNo=()=>{
    let min = 1000;
    let max = 5000;

    return Math.floor((Math.random()*(max-min))+min)
}
console.log(randomNo());
let p1 = new Promise((resolve, reject)=>{
    resolve("1st promise is executed");
},)

let p2 = new Promise((resolve, reject)=>{
    // resolve("2nd promise is executed");
    reject("opps, 2nd promise is failed")
})

let p3 = new Promise((resolve, reject)=>{
    resolve("3rd promise is executed");
})

let promseAll = Promise.all([p1, p2, p3]);
promseAll.then((value)=>{
    console.log("all value is resolved", value);
})
.catch((value)=>{
    console.log("wait one value is not resolved", value);
})