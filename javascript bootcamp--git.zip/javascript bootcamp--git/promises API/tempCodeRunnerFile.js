let p2 = new Promise((resolve, reject)=>{
    setTimeout(()=>{
        // reject(new Error("process 2 can't be executed"));
        reject("process 2 can't be executed");
        // reject(new Error("process 2 can't be executed"));
        }, randomNo())
});