let arr = [2, 3, 4, 5, 6, 7, 8, 9];
let [a, b, c, d, ...rest] = arr;
console.log(a);
console.log(b);
console.log(c);
console.log(d);
console.log(rest);