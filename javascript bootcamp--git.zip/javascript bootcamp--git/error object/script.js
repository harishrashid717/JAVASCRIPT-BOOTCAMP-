// try{
//     let age = prompt("enter your age")
//     age = Number.parseInt(age);

//     if(age>150){
//         console.log("this is probably not your age");
//         let result = confirm("have you entered your correct age ")

//         if(result){
//             throw new ReferenceError("your age is beyound our limit")
//         }
//     }
// }
// catch(err){
//     alert(err.name + " occured as " + err.message + " ----- " + err.stack);
//     // alert(err.stack);
// }


function foo() {
    throw new Error("This is an example error");
}

function bar() {
    foo();
  }
  
  function baz() {
    bar();
  }
  
  try {
    baz();
  } catch (error) {
    console.error(error.stack);
  }
