let element = document.getElementById("pm-text")
document.write(element);
console.log(element);
if(element.nodeType === Node.ELEMENT_NODE){
    document.write("Element node");
    let name = element.nodeName;
    let nodeval = element.nodeValue;
    document.write(name);
    document.write(nodeval);
}
else{
    document.write("not a element node");
}