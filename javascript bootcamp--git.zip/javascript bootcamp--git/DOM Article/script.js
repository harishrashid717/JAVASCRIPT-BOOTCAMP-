// get element by user id

const userId = document.getElementById('user');
console.log(userId);
userId.style.background = "pink";   

// using querySelector to change the color of the element 
const clr = document.querySelector("#user");
clr.style.background = "red";

// get Elements by class name and changing the color of the elements 
// let demo = [...document.getElementsByClassName('user')];
// demo.forEach((ele)=>{
//     ele.style.background = "red";
// })

// const userClass = Array.from(document.getElementsByClassName('user'))
// userClass.forEach((ele) => ele.style.background = "blue")

// using spread operator
// const userClass = [... document.getElementsByClassName("user")];

// console.log(userClass.parentElement);   
// userClass.forEach((ele) => (ele.style.background= "red"));


// for(let i = 0; i < userClass.length; i++){
//     userClass[i].style.background="orange";
// }
// document.querySelector(".user-query").style.background= "yellow";
// document.querySelector("#user-query").style.background = "yellow";

// const changeColor = Array.from(document.getElementsByClassName('user'));
let changeColor = document.getElementsByClassName('user');
changeColor = Array.from(changeColor);
changeColor[1].style.background= "yellow";
changeColor[2].style.background= "red";
for(let i = 0; i < changeColor.length; i++){
    changeColor[i].style.background= "yellow";
}

let tagName = document.getElementsByTagName("section");
for(let value of tagName){
    value.style.background = "green";
}

// // to select the tags from index number 
// const randomTag = Array.from(document.getElementsByTagName("section"));
// randomTag[0].style.background="yellow";
// const queryAll = document.querySelectorAll('.user-query-all');
// Array.from(queryAll).forEach((ele) => {ele.style.background = "brown"});     