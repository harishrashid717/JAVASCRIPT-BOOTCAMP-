let box = document.getElementsByClassName('box')[0];
console.log(box.innerHTML);
console.log(box.textContent);
console.log(box.outerHTML);