// // creating the string 
// let name = "harish";
// let message = `my name is ${name} and last name is rashid`;
// console.log(message);
// console.log(message.lastIndexOf("name"));

// console.log(message.indexOf("harish"));

// let num = 44;
// num = String(num);
// console.log(typeof num);

// let x = 43;
// x =  x + " ";
// console.log(typeof x);

// let y = 0;
// y = y.toString();
// console.log(typeof y);

// let info = new String("alpha 1 ");
// console.log(info.valueOf());

// let text = "Hello, world!";
// let pattern = /world/;

// let result = text.search(pattern);

// console.log(result); // Output: 7

let text = "Hello, world! Wonderful world!";
let substring = "world";
let index = -1;

while((index = text.indexOf(substring, index+1)) !== -1){
    console.log("found at index " ,index);
}

