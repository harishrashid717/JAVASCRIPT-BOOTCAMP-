const arr= [1, 2, 3, 4, 5];

arr.filter((n, i, arr)=>{
    return n%2==0;      
})