const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

numbers.forEach(function(number, index) {
    if (index < numbers.length / 2) {
        console.log(`Element at index ${index}: ${number}`);
    }
});

let newArr= numbers.forEach((n, i, arr)=>{
   arr[i] = n*n;
});
console.log(newArr);