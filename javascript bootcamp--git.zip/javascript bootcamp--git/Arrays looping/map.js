const num = [1, 2, 4, 5, 6, 7, 8, 9];

const sqValue = num.map((n, i, arr)=>{
    return n*n;
});

console.log(sqValue);