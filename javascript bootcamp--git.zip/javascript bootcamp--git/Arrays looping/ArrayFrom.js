// const nameList = document.querySelectorAll('#nameList li'); // NodeList of <li> elements

//         const upperCaseNamesWithIndexes = Array.from(nameList, function(name, index) {
//             return `${index}: ${name.textContent.toUpperCase()}`;
//         });

//         console.log(upperCaseNamesWithIndexes); // Outputs an array of strings
// console.log(typeof nameList);

// let listName = document.querySelectorAll('#nameList li');
// let listName = document.getElementById('nameList li');

// let nameList = Array.from(listName);

// nameList.forEach((ele)=>{
//     console.log(ele.textContent.toUpperCase());
    
// })

const divElement = document.getElementById('myDiv');
        const customValue = divElement.dataset.customValue;

        console.log(customValue);