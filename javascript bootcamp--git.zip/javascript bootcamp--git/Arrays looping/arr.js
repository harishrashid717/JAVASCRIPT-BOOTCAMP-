let arr = [1, 5, 2, 4];

// for each loop 
arr.forEach((ele, index)=>{
    console.log(ele + index);
})

// for of loop 
for(let ele of arr){
    ele +=100; // it will not work 
}
// console.log(arr);

// map method 

let mappedArray = arr.map((ele, index)=>{
    return ele + index + 10;
})
console.log(mappedArray);

// filter method 
let  filteredArray = arr.filter((ele, index, arr)=>{
    return ele%2 == 0;
})
console.log(filteredArray);
let age = 8;
(age>18) ? console.log("you can drive") : console.log("you can't drive ");

// reduce method 
let reducedArr = arr.reduce((acum, ele , index, arr)=>{
    return acum+=ele;
}, 4);
console.log(reducedArr);