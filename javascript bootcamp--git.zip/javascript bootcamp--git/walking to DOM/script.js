// let current = document.getElementsByClassName("sign-in");
// let second = current.previousElementSibling;
// console.log(second.textContent);

// var current = document.getElementById("current");
// var previous = current.previousElementSibling;
// console.log(previous.textContent); // Output: Item 2

// const changBG = () =>{
//     document.body.firstElementChild.style.background="red";
// }
let bodyElement = document.body;
let second = bodyElement.children[3];
let third = second.firstElementChild;
// console.log(second);
// console.log(second.rows);
console.log(third)
console.log(second);
let cardTitle = document.getElementsByClassName("card-title")[0];
cardTitle.Style.color= "red";

let nameColor= document.getElementsByClassName("name");
nameColor.style.color = "red";