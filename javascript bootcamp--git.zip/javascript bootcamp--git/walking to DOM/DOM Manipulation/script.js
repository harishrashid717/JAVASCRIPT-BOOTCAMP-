// let moviesList = document.getElementsByClassName("movies-list");
// console.log(moviesList);
// moviesList.style.color="red"

// let listHeading = document.querySelectorAll(".list-heading");
// console.log(listHeading);
// listHeading[0].style.color = "red"
// listHeading[1].style.color = "blue"
// listHeading[2].style.color = "green"
// listHeading[3].style.color = "yellow"
// listHeading[4].style.color = "pink"
// let moviesHeading = document.querySelector("#movies-heading");
// moviesHeading.style.background= "blue";
// console.log(document.getElementsByTagName("li"));
// console.log(document.querySelector(".movies-list").getElementsByClassName("list-heading"))
// let cosnt = document.getElementsByClassName("favourite-movies")
// console.log(cosnt.matches("#movies-heading"))
// console.log(pp1.closest(".list-heading"));
let ele = document.getElementsByClassName("list-heading")
console.log(ele)
// console.log(ele.closest(".movies-list"))
console.log(".favourite".contains(".container"))