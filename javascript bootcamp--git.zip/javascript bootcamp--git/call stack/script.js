let foo =() =>{
    throw new Error ('oops cannot able to load');
}

let buss = () => foo();

let buzz = () => buss();

buzz();