function getCheese (callBack){
    setTimeout(()=>{
        const cheese = "🍰";
        callBack(cheese);
    }, 1000)
};

getCheese((cheese)=>{
    console.log("here is your cheese " + cheese);
})  