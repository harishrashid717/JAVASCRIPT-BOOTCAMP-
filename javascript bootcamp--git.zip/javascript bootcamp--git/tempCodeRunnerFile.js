document.body.style.background = "red";
// location.href = "https://www.google.com/";