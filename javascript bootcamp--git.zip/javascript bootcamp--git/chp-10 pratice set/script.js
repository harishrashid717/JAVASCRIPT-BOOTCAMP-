let quote = fetch("https://anime-facts-rest-api.herokuapp.com/api/v1");
quote.then((response)=>{
    return response.json()
}).then((value)=>{
    console.log(value);
})
