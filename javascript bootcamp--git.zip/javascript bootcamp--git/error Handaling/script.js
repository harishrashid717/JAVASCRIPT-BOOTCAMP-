setTimeout(()=>{
    console.log("starting executing");
}, 2000)

try{
    console.log(name1);
}
catch(err){
    alert(err);
}
console.log("execution ended");
