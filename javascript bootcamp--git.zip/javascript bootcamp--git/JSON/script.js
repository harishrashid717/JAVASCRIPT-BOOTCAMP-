async function datafetch(){
try {
    let data = await fetch("file.json");
    data = await data.json();
    return data;
} catch (error) {
    console.log("error occuredd :", error.message);
}
}
datafetch().then((response)=>{
    console.log(response.items);
    console.log(response.items[0]);
    console.log(response.items[1].fields.title);
    const {title, price} = response.items[1].fields;
    console.log(title, price);
})