
// Create a new 'div' element
const newDiv = document.createElement('div');

// Set the 'id' and 'class' attributes for the new 'div'
newDiv.setAttribute('id', 'banner');
newDiv.setAttribute('class', 'banner-text');

// Append the new 'div' to the 'body' of the document
document.body.appendChild(newDiv);

// Attempting to find an element with the class 'banner-text' immediately after creation
let textEle = document.getElementsByClassName('banner-text')[0];
console.log(textEle);


// Creating a reference to the element with the 'id' 'banner' after appending
let fstDiv = document.getElementById('banner');

// Create another 'div' element
let aDiv = document.createElement('div');

// Set the 'id' and 'class' attributes for the new 'div'
aDiv.setAttribute('id', 'my-div');
aDiv.setAttribute('class', 'my-div-class');

// Append the new 'div' to the 'fstDiv'
fstDiv.appendChild(aDiv);


// creating a new script and appending in the body of the html file 

    function loadScript(link, callback){
        setTimeout(()=>{
            let script = document.createElement('script');
            script.src = link;
            document.body.appendChild(script);
            callback(script);
        })
    }
    let link = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css";
    loadScript(link, (script)=>{
        console.log(script);
    })
