let themeBtn = document.getElementById("myBtn");
let body = document.querySelector("body");

themeBtn.addEventListener('click', ()=>{
    body.classList.toggle('background-black');
    body.classList.toggle('background-white');
});