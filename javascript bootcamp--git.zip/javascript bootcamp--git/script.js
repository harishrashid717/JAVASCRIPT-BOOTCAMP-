console.log(console);
console.error("this is an errror");
console.assert(55>666);
console.info("hey my name is harish rashid");
console.warn("do not click it again");
const info = {
    a : 4,
    b : 5, 
    c : 6
};
console.table(info);
console.time(info);
console.timeEnd(info);

console.time("forloop");
for(let i = 0; i < 8; i++){
    console.log("harish rashid");
}
console.timeEnd("forloop");
// alert("enter your name ");
// let name = prompt("write your name is this window");
// let write = confirm("please check your name again and press ok, or else cancel it ");
// if(write==true){
//     document.write("Name : " + name);
// }
// else{
//     document.write("please enter your name onceagain")
// }
// document.body.style.background = "red";
// location.href = "https://www.google.com/";

alert("problem no 1");
let runAgain = true;
while(runAgain){
let age = prompt("enter your age ");
Number.parseInt(age);
if(age<0){
    console.error("please enter a valid age");
}
canDrive = (age) =>{
    age>=18 ? true : false;
}
if(canDrive(age)==true){
    alert("you can drive");
}
else{
    alert("you can't drive");
}
 runAgain = confirm("do you want to see it agian");

}