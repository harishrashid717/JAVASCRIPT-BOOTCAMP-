let loadScript = (url)=>{
    return new Promise((resolve, reject)=>{
        let bootstrapScript = document.createElement('script');
        bootstrapScript.src = url;

        bootstrapScript.onload = {
        }
    })
}