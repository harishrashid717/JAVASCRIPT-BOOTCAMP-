// const arr = [1, 23, 4, 5, 3, 1, "harish"];
// console.log(arr);
// console.log(arr.length);
// arr[0] = 33;
// console.log(arr.length);
// console.log(arr);
// let brr = arr.push("rashid");
// console.log(arr);
// console.log("brr is ", brr);
// let newArr= arr.pop();
// console.log(arr);
// console.log(newArr);
// console.log(brr);
// console.log(typeof arr);
// const newARR = arr.join("--topper--");
// console.log(newARR);

const numbers = [1, 2, 3, 4, 20 ,3 ,4, 3];
let arr = numbers;
arr.forEach((ele)=>{
    console.log(ele);
})
// numbers.splice(2, 2, 10, 20); // Insert 10 and 20 at index 2
// console.log(numbers);

// for each loop 

// numbers.forEach((ele, index, arr)=>{
//     console.log("product of element at index " +index + " is " + (ele*ele) + " of an array " + arr);
// })

// map method 

// let newArray = numbers.map((ele, index, array)=>{
//     return ele + index;
// })
// console.log(newArray);

// filter method 

// let filteredArray = numbers.filter((ele, index, array )=>{
//     return (ele % 2)===0;
// })
// console.log(filteredArray);

// numbers.unshift(77);
// delete numbers[2];

// numbers.splice(0, 3, 44, 5,5, 3);
// console.log(numbers);

// let arr = [2, 3, 1, 4, 1, 3];
// let brr = arr.reduce((accum, ele, index)=>{
//     debugger;
//     return accum + ele;
// }, 5  /*initial value */ )
// console.log(brr);

