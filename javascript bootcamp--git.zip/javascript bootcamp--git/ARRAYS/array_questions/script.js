// let arr = [];
// let i =1;
// while(i<4){
//     arr.push(i);
//     i++;
// }
// console.log(arr);

// 2nd questions 
// let numbers = [4, 2, 8, 6];
// numbers.push(10);
// numbers.shift();
// console.log(numbers);
// numbers.unshift(88);
// console.log(numbers);

// 3rd questions splice method 
// let br = [34, 32, 1, 33, 21, 12, 122, 99];
// br.splice(2, 3, 44, 22, 11);
// console.log(br);

// finding the largest element in the array '
// let num = [33, 1, 55, 34, 132];

// let maxNum = num.reduce((accum, currentEle)=>{
//     debugger
//     return Math.max(accum, currentEle);
// })
// console.log(maxNum);

// Given an array of numbers originalArray = [1, 2, 3, 4, 5], create a new array squaredArray that contains the squares of each number.
let originalArray = [1, 2, 3, 4, 5];
let mappedArray = originalArray.map((ele)=>{
    return ele*ele;
})
console.log(mappedArray);