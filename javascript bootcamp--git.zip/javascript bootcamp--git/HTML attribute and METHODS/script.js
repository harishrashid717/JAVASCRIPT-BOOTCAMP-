let a = document.getElementById("hey");
let b = a.getAttribute("class");
// console.log(b);
// console.log(a.hasAttribute("class"));

// a.setAttribute("hidden", "true");

console.log(a.attributes);
console.log(a.dataset);