
let p1 = new Promise((resolve, reject)=>{
    setTimeout(()=>{
        resolve("1st resolve")
    }, 3000)
})
p1.then((value)=>{
    document.write(value);

})
p1.then(()=>{
    return new Promise((resolve , reject)=>{
        resolve("Inside p1 promise get resolved")
    })
}).then((value)=>{
    document.write(value);
})