// console.log("first");
// setTimeout(()=>{
//     console.log("it will execute later");
// }, 3000);
// console.log("second");

function getcheese(gotCheese){
    setTimeout(()=>{
        const cheese = "🍰";
        console.log("here is your cheese" , cheese);
        gotCheese(cheese);
    }, 2000)
}

getcheese((cheese)=>{
    console.log("got my cheese ", cheese);
})
