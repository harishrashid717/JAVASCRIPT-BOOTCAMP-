const cheese = (callBackCheese)=>{
    setTimeout(() => {
        let cheese = "🍰"
        readyCheese=()=>{
            console.log("your cheese is ready", cheese);
        }
        console.log("here is your cheese", cheese);
        callBackCheese(readyCheese);

    }, 2000);
}

cheese(callBackcheese=()=>{
    readyCheese();
    // console.log("your cheese is ready", cheese);
});

