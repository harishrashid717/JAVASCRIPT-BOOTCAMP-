// cheese -> dough -> pizza

// cheese making

function cheeseMaking (callBackCheese){
    setTimeout(() => {
        const cheese = "🍰";
        console.log("making cheese...", cheese);
        callBackCheese(cheese)
    }, 1000);
}

// dough making 

function doughMaking (cheese, callBackDough){
    setTimeout(() => {
        const dough = "🫓"
        console.log("dough making ...", cheese, dough );
        callBackDough(dough)
    }, 1000);
}

// pizza baking 

function pizzaBaking (callBackPizza){
    setTimeout(() => {
        const pizza = "🍕"
        console.log("pizza baking... ", pizza,pizza,pizza);
        callBackPizza(pizza)
    }, 1000);
}

cheeseMaking((cheese)=>{
    console.log("cheese is ready");
    doughMaking(cheese, doughMaking = () =>{
        console.log("dough is ready");
        pizzaBaking( pizzaBaking=()=>{
            console.log("pizza is ready");
            console.log("enjoy your meal");
        })
    })
})