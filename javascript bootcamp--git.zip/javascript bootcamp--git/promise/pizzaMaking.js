// cheese making

function cheeseMaking(){
    return new Promise((resolve, reject)=>{
        setTimeout(()=>{
            const cheese = "🍰";
            resolve(cheese);
        }, 2000);
    });
}

function doughMaking (cheese){
    return new Promise((resolve, reject)=>{
        setTimeout(() => {
            const dough = cheese + "🫓";
            resolve(dough)
        }, 2000);
    });
}

function pizzaBacking (dough){
    return new Promise((resolve, reject)=>{
        setTimeout(() => {
            const pizza = dough + "🍕";
            resolve(pizza)
        }, 2000);
    })
}



// cheeseMaking()
//     .then((cheese)=>{
//         console.log("here is your cheese", cheese);
//         return doughMaking(cheese);
//     })
//     .then((dough)=>{
//         console.log("here is your dough ", dough);
//         return pizzaBacking(dough)
//     })
//     .then((pizza)=>{
//         console.log("here is your pizza", pizza);
//     })
//     .catch((data)=>{
//         console.log("error occured due to " , data);
//     })
//     .finally(()=>{
//         console.log("process ended");
//     })

    // Asynchronous function

    async function orderPizza(){
        try{
        console.log("order pizza...!");
        const cheese = await cheeseMaking();
        console.log("here is your cheese", cheese);
        const dough = await doughMaking(cheese);
        console.log("here is your dough ", dough);
        const pizza = await pizzaBacking(dough);
        console.log("here is your pizza", pizza);
    } catch(data){
        console.log("error occured ", data);
    }
    console.log("process ended ");
    }
    orderPizza()