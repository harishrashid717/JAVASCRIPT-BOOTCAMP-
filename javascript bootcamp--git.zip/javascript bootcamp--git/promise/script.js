
// const ticket = new Promise((resolve, reject) =>{
//     let isBoaded = true;
    
//     if(isBoaded){
//         resolve("your flight is successfully taken of..!")
//     }
//     else{
//         reject("your ticket has been cancelled");
//     }
// })

// ticket
//     .then((data) =>{
//         console.log("yes", data);
//     })
//     .catch((data)=>{
//         console.log("no", data);
//     })

let p1 = new Promise((resolve , reject)=>{
    setTimeout(()=>{
        resolve("ok resolved")
    }, 2000)
})

console.log(p1.then((value)=> {return value;}));

let p2 = new Promise ((resolve, reject )=>{
    resolve("resolved");
})
let num = p2.then((value)=>{
    return value;
});
console.log(num);