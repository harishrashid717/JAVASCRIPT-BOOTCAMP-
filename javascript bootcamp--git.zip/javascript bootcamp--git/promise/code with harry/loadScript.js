
let createScript = new Promise ((resolve, reject)=>{
    let script = document.createElement('script');
    script.src = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js";

    script.onload = ()=>{
        resolve("script is loaded")
    }

    script.onerror = ()=>{
        reject(new Error("Invalid script"))
    }
    document.body.appendChild(script);
})

createScript.then((value)=>{
    document.write(value);

}).catch((value)=>{
    document.write(value)
})

// loading bootstrap script

let loadBootstrapScript = ()=>{
   return new Promise((resolve, reject)=>{
        let script = document.createElement('script');
        script.src = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js";

        // script on loading

        script.onload = ()=>{
            resolve("script is successfully added")
        }

        script.onerror = ()=>{
            reject(new Error ("failed to load"));
        }

        document.body.appendChild(script);
    })

    // return script;
}

loadBootstrapScript().then((value)=>{
    document.write(value);
})

loadBootstrapScript().catch((value)=>{
    document.write(value);
})
