// let promise = new Promise((resolve, reject)=>{
//     resolve(88);
// })
// console.log("promise is successfully resolved" + promise.then());

let burger = new Promise((resolve, reject)=>{
    console.log("burger delivery is pending");
    askDeliveryBoy = () =>{
       let ans =  confirm("Is the product delivered by you ?");
       return ans;  
    }
    setTimeout(()=>{

        let delivery = askDeliveryBoy();
        if(delivery){
            // console.log("BURGER IS SUCCESSFULLY DELIVERED");
                let result = ()=>{
                    let msg = "The product is successfully delivered";
                    return msg;
                }
                resolve(result());
        }
        else{
          let result = ()=>{
            let msg = "Sorry for the inconvenience , we can't deliver Burger right now ";
            return msg;
          }
          reject(new Error(result()))
        }
    }, 3000)
});
console.log(burger);
let state =  document.getElementById('deliveyState');

// 1st method

burger.then((value)=>{
    state.textContent = value;
    console.log(value);
})

burger.catch((value)=>{
    // document.write(value);
    state.textContent = value;

})

// 2nd method

// burger.then((value)=>{
//     state.innerHTML = value;
// }, (error)=>{
//     state.innerHTML = value;
// })

