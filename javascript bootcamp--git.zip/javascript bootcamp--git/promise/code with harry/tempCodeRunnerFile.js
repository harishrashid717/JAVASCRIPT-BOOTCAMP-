let promise = new Promise((resolve, reject)=>{
    resolve(88);
})
console.log("promise is successfully resolved",  promise);