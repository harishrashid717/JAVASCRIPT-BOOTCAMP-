function pizzaDelivery(){
    return new Promise((resolve, reject)=>{
        let status = ()=>{
            let ans = confirm("is the pizza ready for deliver ?");
            return ans;
        }
        setTimeout(()=>{
            const deliveryStatus = status();
            if(deliveryStatus){
                resolve("pizza is on the way, have some patience ");
            }
            else{
                reject("sorry for the inconvenience, your pizza can't be delivered");
            }
        }, 2000)
    })
}

let state = document.getElementById('state');

pizzaDelivery()
  .then((value) => {
    alert(value);
    state.textContent = "Shipping....";
  })
  .catch((value) => {
    alert(value);
    state.textContent = "Failed to deliver...❌";
  });