// let p1 = new Promise(resolve=>{
//     resolve("file executed");
// })
// p1.then((msg)=>{
//     console.log(msg);
// })

let p1 = new Promise((resolve, reject) => {
    // Simulating an error here
    // For example, you can use: reject("An error occurred during step 1");
    resolve("file executed");
});

p1.then((msg) => {
    console.log(msg);
})
.catch((error) => {
    console.error("Error during step 1:", error);
})
.then(() => {
    // Another asynchronous operation
    // throw new Error("Another error occurred during step 2");
    resolve("step 2 is resolved")
})
.catch((error) => {
    console.error("Error during step 2:", error);
})
.then(() => {
    console.log("Continuing after errors");
});
