function pizzaDelivery () {
    return new Promise((resolve, reject)=>{
        let DeliveryTime = prompt("how many minutes will it take to deliver pizza");
        DeliveryTime = Number.parseInt(DeliveryTime);
        DeliveryTime = DeliveryTime*1000
        if(isNaN(DeliveryTime)){
            reject(new Error("Invalid Delivery Time"))
        }
        else{
        setTimeout(()=>{
            let state = prompt("is the product delivered by you");
            if(state === "yes"){
                resolve("Your pizza has been successfully delivered");
            }
            else{
                alert("Sorry for the inconvience , we can't delievr you pizza right now ")
                reject(new Error("Failed to deliver"))
            }
        }, DeliveryTime);
    }
    })
}

let pizzaState = document.getElementById("delivery-state");
pizzaDelivery()
    .then((value)=>{
    pizzaState.textContent = value;
    })
    .catch((value)=>{
    pizzaState.textContent = value;
    });