let ele = document.getElementsByClassName('container')[0];
ele.className += " newContainer"
console.log([...document.getElementsByClassName('container')][0].classList);