let key = prompt("enter the key ");
let value = prompt("enter the value ");

document.cookie = `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
console.log(document.cookie);  
// console.log(decodeURIComponent(document.cookie)); throw an error to decode usedecodeURIcomponent(pass here coded value) in the browser console