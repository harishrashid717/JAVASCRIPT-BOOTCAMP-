let a = Symbol("harish");
console.log(typeof a);
// we can't alert the symbol variable as it's a symbol type to alert a symbol variable we have to first convert it into the string
alert(a.toString());