let a = Boolean("harish");
console.log(a);
console.log(typeof a);
let b = Boolean(true);
console.log(b);

let c = new Boolean(true);
console.log(c);