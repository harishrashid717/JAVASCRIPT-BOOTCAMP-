const random = document.querySelectorAll('.container .box');
console.log(random);

let box1 = document.getElementById("box-2");
// box1.innerHTML= "<h1>hello world</h1>";

// box1.style.color = "red";
// console.log(box1.classList);

// let box3 = document.getElementById("box-3");
// box3.classList.add("round-border");

let boxes = document.getElementsByClassName("box");

for(let i = 0; i < boxes.length; i++){
    boxes[i].classList.add("round-border");
}
function myFunction () {
    console.log("clicked me");
}

function mouseMove(){
    console.log("i was moved");
}

const mouseOver = () =>{
    console.log("i was hovered");
}