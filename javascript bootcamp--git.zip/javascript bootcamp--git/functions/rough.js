let calculate = (a, b, add)=>{
    return add(a,b);
}

let result = calculate(2, 3, (a, b)=>{
    return a+b;
})
console.log(result);