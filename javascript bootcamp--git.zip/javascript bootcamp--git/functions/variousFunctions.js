// FUNCTION DECLARATION --> this type of function is declared at the top of it's scope means, we can call it before the function actually created..

console.log(addNum(4,5));

function addNum(a,b){
    return a+b
}

// function expression :- this type of function is not declared at the top of it's scope means first we have to create the function and then we have to call it..

let addSquare = function(a,b){
    function square (x){
        return x*x;
    }
    return square(a) + square(b);
}
console.log(addSquare(3,4));

// arrow function 

const sq = (a) => console.log("square of a ");
