let age = 15;
let drive = (age>= 18) ?
()=> console.log("you can drive"):
()=> console.log("you can't drive");
drive();
// let name = "harish rashid";
// const demo  = (name) = console.log("your name is " + name);

const greet = () =>{
    console.log("hello ");
}
greet();

const add = (a, b) => a+b;
console.log(add(3,4));

const addSquare = (a, b) =>{

    const square = (x) => x*x;

    return square(a) + square(b);
};
const sub = (a, b) => a-b;
console.log("The diffrence is " + sub(7, 2));
console.log(addSquare(2, 3));
