// function declaration
function sq(a){
    return a*a;
}
let num =6;
console.log("the square of  number is " + sq(5));

// function expression
const varr = function(num){
    return num*num;
}
console.log(varr(num));

// nested function

const addSquare = function(a, b){
    function square(x){
        return x*x;
    }
    return square(a) + square(b);
}

console.log(addSquare(2, 3));

let greet = (count) =>{
    for(let i = 0; i < count ; i++)  console.log("hello buddy");
}
greet(4);

// arrow function with no argument 
let greetMe = () => console.log("hello this is me ");
greetMe();

// arrow function with one argument 

let mySq = x => console.log("the square is " + x*x);
mySq(6);

// arrow function as expression

let age = 20;

const vote = (age>18) ? console.log("you can vote ") : console.log("you can't vote");