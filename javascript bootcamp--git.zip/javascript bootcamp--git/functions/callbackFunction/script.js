// let operation = (a, b, calculate) =>{
//     return calculate(a,b);
// }

// let addition = (a, b) => a+b;
// let multiplication = (a,b) => a*b;
// let division = (a,b) => a/b;

// let result = operation(2, 3, multiplication);
// console.log(result);

const greet = x => console.log(x);
greet("hello world. i am harish");