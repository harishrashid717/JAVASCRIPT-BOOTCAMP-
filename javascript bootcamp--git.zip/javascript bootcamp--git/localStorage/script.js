// let key = prompt("enter the key ");
// let value = prompt("enter the value ");

// localStorage.setItem(key , value);
// // another way to store data in the local storage 
// localStorage.favFood = "rice"
// // let val1 = localStorage.getItem("colour");
// console.log(localStorage.getItem("colour"));
// console.log(localStorage.getItem("favFood"));

let info = {
    name : "hairsh rashid", 
    age : 22,
    enrollmentNo : 908
}

// setting in the local storage

localStorage.setItem("empInfo", JSON.stringify(info));
console.log(localStorage.getItem("empInfo"));
console.log(JSON.parse(localStorage.getItem("empInfo")));