const details= {
    firstName : "harish" ,
    lastName : "rashid",
    fullName : ()=> details.firstName + " " + details["lastName"],
    marks : {
        english : 99,
        maths : 77
    },
    totalMarks : ()=> details.marks.english + details.marks.maths
};

console.log(details.firstName);
console.log(details["lastName"]);
console.log(details.fullName());
console.log(details.marks);
console.log(details.marks.english);
console.log(details.totalMarks());