// usecases

// 1.write code to get array of names from given array of users
// 2. get back only active users 
// 3 short array by age decending

const users = [
    {
        id: 1,
        name: "harish",
        isActive : true,
        age : 20
    },
    {
        id: 2,
        name: "rashid",
        isActive : false,
        age : 14
    },
    {
        id: 3,
        name: "aaryan",
        isActive : true,
        age : 20
    },
    {
        id: 4,
        name: "sunny",
        isActive : false,
        age : 18
    },

]

const names =[];

for(let i = 0; i < users.length; i++){
    names.push(users[i].name);
}
document.write(names);
