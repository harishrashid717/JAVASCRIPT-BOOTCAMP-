console.log(console);
console.assert(0>5 , "not true ")
console.time("forLoop");

for(let i = 0; i < 6; i++){
    console.log("harish rashid");
}
console.timeEnd("forLoop");