function createScript(url, callback){
    let script = document.createElement('script');
    script.src = url;

    script.onload = () =>{
        alert("script is sucessfully added");
        callback(null, script.src);
    }
    
    script.onerror = () =>{
        alert("failed to load the script");
        callback(new Error("undefined url"));
    }
    document.body.appendChild(script);

}

function statusOfScript(error, url){
    console.log(error);
    if(error){
        alert(error)
    }
    else{
        // alert("add another script");
        alert("script is sucessfully added  and url is ", url);
    }
}

createScript("https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js", statusOfScript)   