// function addScript(url, statusCallback){
//     let script = document.createElement('script');
//     script.src = url;

//     script.onload = () =>{
//         statusCallback(null, url);

//         document.body.appendChild(script)
//     }
//     script.onerror= ()=>{
//         statusCallback(new Error("Invalid url"), url)
//     }
// };

// let statusCallback = (error, url)=>{
//     if(error){
//         alert("Provided url " + url + " " +  error);
//     }
//     else{
//         alert("script " + url + " sucessfully added ");
//     }
// }

// let url = prompt("enter the url");
// addScript(url, statusCallback);

function addScript(url, statusCallback){
    let script = document.createElement('script');
    script.src = url;

    script.onload = () =>{
        statusCallback(null, url);

        document.body.appendChild(script);
    };
    script.onerror= ()=>{
        statusCallback(new Error("Invalid url"), url);
    };
}

let statusCallback = (error, url)=>{
    if(error){
        alert("Provided url " + url + " " + error); // Convert error to string
    }
    else{
        alert("Script " + url + " successfully added");
    }
};

let url = prompt("Enter the URL");
addScript(url, statusCallback);
