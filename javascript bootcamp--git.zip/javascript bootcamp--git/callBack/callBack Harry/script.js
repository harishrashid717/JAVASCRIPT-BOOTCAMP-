
// function execute(text, callback){
//     let name = "harish " +  text ;
//     callback(name);
// }

// let hello = () => console.log("hello world");


// // let printName = () => console.log("my name is " + name);

// // execute("harish");

// execute( "rashid", (name)=>{
//     console.log(name);
// })

// creating a script and executing when it's completely loaded

function createScript (src, callback){
    let script = document.createElement('script');
    let scriptSrc = script.src
    scriptSrc = src;
    script.onload = callback(script, scriptSrc);
    script.onerror = ()=>{
        console.log("error in loading the page");
        // callback(script);
    }
    // document.body.append("script");
}

createScript("https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js", (script, scriptSrc)=>{
    document.body.append("script");
    alert("script " + script + " successfully added");
    alert(scriptSrc);
});

