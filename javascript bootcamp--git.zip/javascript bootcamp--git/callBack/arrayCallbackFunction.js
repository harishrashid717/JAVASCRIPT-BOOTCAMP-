const arr = [1, 3, 4, 5, -4 , 10. -33, 0 , 8];

const firstNeg = (num) =>{
    return num < 0;
}

// let result = arr.find(firstNeg);
// console.log(result);

// let result2 = arr.findIndex(firstNeg);
// console.log(result2);

arr.forEach((num , i) =>{
    console.log("array sq " + num*num + " at index " + i);
})

function myFunction(callBack) {
    setTimeout(()=>{
        callBack([1, 3, 4]);
    }, 2000)
}

let add = (arr) =>{
    let sum = 0;
    for(let num of arr){
        sum = sum + num;
    }
    console.log("the sum of the array element is " + sum);
}

myFunction(add);    