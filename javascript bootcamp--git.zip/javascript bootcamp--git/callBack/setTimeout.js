const sayHello = (name) => console.log("hello " + name + "!");

setTimeout(sayHello, "harish", 2000);

setTimeout(()=>{
    console.log("my name is harish rashid ");
}, 3000);

