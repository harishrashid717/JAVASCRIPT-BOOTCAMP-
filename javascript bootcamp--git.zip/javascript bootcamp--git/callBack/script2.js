

function register (callbackRegister){
    setTimeout(() => {
        console.log("registar end");
        let email = "harishrashid717@gmail.com";
        callbackRegister();
    }, 1000);
}

function sendEmail (callbackEmail){
    setTimeout(()=>{
        console.log("email sended");
        callbackEmail();
    }, 1000);
}

function login(callbackLogin){
    setTimeout(() => {
        console.log("you have successfully log in");
        callbackLogin()
    }, 1000);
}

function getUserData(callbackGetuserdata){
    setTimeout(()=>{
        console.log("data successfully generated");
        callbackGetuserdata()
    }, 1000);
}

function displayUserdata(callbackDisplayuseardata){
    setTimeout(() => {
        console.log("data successfully displayed");
        callbackDisplayuseardata();
    }, 1000);
}

register(()=>{
    sendEmail(()=>{
        login(()=>{
            getUserData(()=>{
                displayUserdata(()=>{
            
                }) 
            }) 
        }) 
    })
})
console.log("other important works");