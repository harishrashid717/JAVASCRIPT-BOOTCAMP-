let reigister = ()=>{
    setTimeout(()=>{
        console.log("register completed");
    }, 3000)
    console.log("other work than set timeout");
}

let anotherFunction = () => {
    reigister();
    console.log("execution started ");
}
anotherFunction();
console.log("other important works ");