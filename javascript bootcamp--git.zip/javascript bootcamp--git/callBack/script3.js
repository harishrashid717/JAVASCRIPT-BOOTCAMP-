
let add = (n1, n2, callback) =>{
    let sum = n1 + n2;
        callback(sum);
}

add(1, 3, (result)=>{
    console.log(result);
})

function myFunction(a, b, callback){
    let sum = a+b;
    callback(sum);
}

myFunction(3, 5, (add)=>{
    console.log("sum is " + add);
})