// simple callback function 
function doSomething(callback){

    // perform the task 
    setTimeout(()=>{

        callback();
    }, 1000)
}

function callBackFunction() {
    console.log("I am callback function");
}
doSomething(callBackFunction);

// 2nd example 

let getPizza =(callback)=>{

    function takePizza(){
        setTimeout(()=>{
            let pizza = "🍕";
            return pizza;
        }, 1000)
    }
    callback(takePizza);

}

getPizza((takePizza)=>{
    let piz = takePizza();
    console.log(`here is your ${takePizza()}`);
})
// let a = 5, b = 6;
// const calculate = (a, b, operation) => {
//     return operation(a,b);
// }

// const addition = (a, b) =>{
//     return a+b;
// }

// const substraction = (a, b) => {
//     return a-b;
// }

// const multiplication = (a, b) => a*b;
// console.log("the result is " + calculate(a, b, multiplication));

// const mainFunction = (callBack) =>{
//     setTimeout(()=>{
//         callBack([1, 2, 4]);
//     }, 3000)
// }

// // adding function

// const add = (arr) =>{
//     let sum = 0;
//     for(let i of arr){
//         sum = sum + i;
//     }

//     console.log("the sum is " + sum);
// }

// mainFunction(add);

// const myFunction = (callback)=>{
//     let temp = [2, 3, 4];
//     setTimeout(()=>{
//         callback(temp);
//     }, 2000);
//     setTimeout(()=>{
//         for(let ele of temp){
//             console.log(ele + " ");
//         }
//     }, 2500);
// }

// function changeElement(arr){
//     let sum = 0
//     for(let ele of arr){
//         sum+=ele;
//     }
//     console.log("sum in the change element is " + sum);
// }
// myFunction(changeElement);