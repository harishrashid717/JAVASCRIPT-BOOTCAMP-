foo();
function foo(){
    var a = 9;
    console.log("hi I am under foo");
}
// console.log(a);       