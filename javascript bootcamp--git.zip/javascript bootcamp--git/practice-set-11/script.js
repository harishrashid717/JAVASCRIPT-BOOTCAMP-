// qn 1-2
class complexNumber{
    constructor(){
        this.realPart = '';
        this.imaginaryPart = '';
    }
    set real(realPart){
      this.realPart = realPart;
    }
    set imaginary(imaginaryPart){
        this.imaginaryPart= imaginaryPart;
      }
    
    get real(){
        return this.realPart;
    }
    get imaginary(){
        return this.imaginaryPart;

    }
    display(){
        console.log(`the complex number is ${this.realPart} + i${this.imaginaryPart}`);
    }
    add(num){
        this.realPart+=num.realPart;
        this.imaginaryPart+=num.imaginaryPart;
    }
}
let num = new complexNumber();
num.real = 2;
num.imaginary = 4;
let num2 = new complexNumber();
num2.real = 3;
num2.imaginary= 8;
num.display();
num.add(num2);
console.log(num.display());

// qn 2-3

class human{
    constructor(sex){
        this.sex = sex;
    }

    info (){
        console.log(`this human is ${this.sex}`);
    }
}

class student extends human{
    constructor(name, sex, age, rollNo){
        super(sex);
        this.name = name;
        this.age = age;
        this.rollNo = rollNo;
    }

    info(){
        super.info();
        console.log(`name is -- ${this.name}, age is-- ${this.age}, gender is-- ${this.sex}, roll number is ${this.rollNo}`);
    }
}

let student1 = new student("harish", "male", 22, 20131010908);
student1.info();

console.log("student is instance of ", student1 instanceof human);