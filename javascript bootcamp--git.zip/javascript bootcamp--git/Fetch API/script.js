let weather = document.getElementById("weather")

let p1 = fetch("https://goweather.herokuapp.com/weather/Sydney");
p1.then((value1)=>{
    // console.log(value1);
    return value1.json();
    console.log(value1.json());
}).then((value2)=>{
    console.log(value2);
    weather.textContent = value2.description;
})