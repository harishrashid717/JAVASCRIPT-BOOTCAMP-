let url = "https://goweather.herokuapp.com/weather/NewDelhi";

fetch(url).then((response)=>{
    console.log(response.ok);
    console.log(response.status);
    if(!response.ok){
        // console.log("Error to load the file");
        throw new Error("Error to load the file");
    }
    else{
        return response.json();
    }
}).then((value)=>{
    console.log(value);
}).catch((value)=>{
    console.log("got an error ", value);
})