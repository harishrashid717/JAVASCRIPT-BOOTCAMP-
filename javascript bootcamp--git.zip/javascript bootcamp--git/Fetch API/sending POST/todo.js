const todo = async()=>{
let options = {
    method : "POST", 
    body : JSON.stringify({
        name: "harish", 
        age : 21, 
        admissionNO : "20scse1010875"
    }),
    headers : {
        "content-type" : "application/json"
    }
}

let pst = await fetch("https://jsonplaceholder.typicode.com/posts", options);
let response = await pst.json();
return response;
}

const fetchInfo = async ()=>{
    let info = await todo();
    console.log(info);
}
fetchInfo();