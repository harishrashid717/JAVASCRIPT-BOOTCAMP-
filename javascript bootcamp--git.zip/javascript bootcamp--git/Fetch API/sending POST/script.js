let options = {
  method: "POST",
  body: JSON.stringify({
    name: "harish rashid",
    age: 10,
    admissionNo: "20scse1010975",
  }),
  headers : {
    "content-type" : "application/json"
  }
};

let pst = fetch("https://jsonplaceholder.typicode.com/posts", options);
setTimeout(()=>{
    let response = pst.json();
    console.log(response);

}, 10000)
// pst.then((response)=>{
//     return  response.json();
// }).then((value)=>{
//     console.log(value);
// })