const createTodo = async (todo) =>{
    const options = {
        method : "POST", 
        body : JSON.stringify(todo),
        headers : {
            "Content-type" : "application/json"
        } 
    }
    let pst = await fetch("https://jsonplaceholder.typicode.com/posts", options);
    if(!pst.ok){
        throw new Error("HTTP error : " , pst.status);
    }

    let response = await pst.json();
    return response;
}

const mainFun = async () =>{
    let todo = {
        name : "harish",
        Adid : "20scse",
        age : 22,
    }
    try {

        let response = await createTodo(todo);
        // let data = await response.json();
        console.log(response);
    }
    catch(error){
        console.log("got an error", error);
    }
}
mainFun();
