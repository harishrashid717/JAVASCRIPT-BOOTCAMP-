let element = document.getElementById("first");
element.className = "text-black red";
element.className.remove("red");
// let arr = element.className;
// console.log(typeof arr);
// console.log(element.className);

// element.classList.add("border");
// element.classList.remove("red");
// console.log(element.classList.contains("border"));