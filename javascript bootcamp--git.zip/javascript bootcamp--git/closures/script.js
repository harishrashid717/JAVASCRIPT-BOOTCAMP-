let foo = function hoo(){
    console.log("hello I am hoo");
}
hoo();