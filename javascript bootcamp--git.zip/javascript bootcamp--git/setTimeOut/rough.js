let getCheese = (callback)=>{
    setTimeout(()=>{
        let cheese = "🍰";
        callback(cheese);
    }, 2000);
}
getCheese((order)=>{
    console.log("your order is ", order);
})