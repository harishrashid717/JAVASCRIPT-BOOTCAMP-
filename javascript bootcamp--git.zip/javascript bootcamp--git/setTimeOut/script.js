function getCheese(calback){
    setTimeout(()=>{
        const cheese = "🍰";
        calback(cheese);
    }, 2000);
}
getCheese((chee)=>{
    console.log("take your cheese " + chee);
})