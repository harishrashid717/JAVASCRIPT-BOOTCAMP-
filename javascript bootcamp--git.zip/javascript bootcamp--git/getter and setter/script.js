class person{
    constructor(){ 
        this._name = "";
    }

    set name(name){
        this._name = name;
    }

    get name(){
        return this._name;
    }

}
let person1 = new person("faishal rashid"); // here _name = faishal rashid will not be initlized in the person1 varibale as no argument is passed in the constructor
console.log(person1.name);
person1.name = "harish rashid";
console.log(person1.name);