let hr = document.getElementById("hrs");
let min = document.getElementById("min");
let sec = document.getElementById("sec");
let newDate = new Date();
let secHand = newDate.getSeconds();
sec.textContent = secHand;
let minHand = newDate.getMinutes();
min.textContent = minHand;
let hrHand = newDate.getHours();
hr.textContent = hrHand;
setInterval(() => {
  let newDate = new Date();
  let secHand = newDate.getSeconds();
  sec.textContent = secHand;
  if (secHand == 0) {
    let newDate = new Date();
    let minHand = newDate.getMinutes();
    min.textContent = minHand;

    if (minHand == 0) {
      let newDate = new Date();
      let hrHand = newDate.getHours();
      hr.textContent = hrHand;
    }
  }
}, 1000);
// console.log(secHand);

// let hr = document.getElementById("hrs");
// let min = document.getElementById("min");
// let sec = document.getElementById("sec");

// function updateClock() {
//     let currentDate = new Date();

//   let secHand = currentDate.getSeconds();
//   sec.textContent = secHand;

//   let minHand = currentDate.getMinutes();
//   min.textContent = minHand;

//   let hrHand = currentDate.getHours();
//   hr.textContent = hrHand;
// }

// updateClock(); // Initial update

// setInterval(() => {
//   updateClock();

//   if (sec.textContent === "0") {
//     let minHand = parseInt(min.textContent);
//     if (minHand === 0) {
//       let hrHand = parseInt(hr.textContent);
//       if (hrHand === 0) {
//         hrHand = 12; // Assuming you want the clock to display 12-hour format
//       }
//       hr.textContent = hrHand - 1;
//     }
//     min.textContent = minHand - 1;
//   }
// }, 1000);

