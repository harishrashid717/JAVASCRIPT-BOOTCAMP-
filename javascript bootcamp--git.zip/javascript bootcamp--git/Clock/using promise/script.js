// let hr = document.getElementById("hrs");
// let min = document.getElementById("min");
// let sec = document.getElementById("sec");
// let newDate = new Date();
// let secHand = newDate.getSeconds();
// sec.textContent = secHand;
// let minHand = newDate.getMinutes();
// min.textContent = minHand;
// let hrHand = newDate.getHours();
// hr.textContent = hrHand;

// let second = new Promise((resolve, reject) => {
//   setInterval(() => {
//     let newDate = new Date();
//     let secHand = newDate.getSeconds();
//     sec.textContent = secHand;
//     resolve(secHand);
//   }, 1000);
// });

// second
//   .then((secHand) => {

//     if (secHand === 0) {
//       let newDate = new Date();
//       let minHand = newDate.getMinutes();
//       min.textContent = minHand;
//       resolve(minHand)
//     }
//   })
//   .then((minHand) => {
//     console.log(minHand);
//     if (minHand == 0) {
//       let newDate = new Date();
//       let hrHand = newDate.getHours();
//       hr.textContent = hrHand;
//     }
//   });


let hr = document.getElementById("hrs");
let min = document.getElementById("min");
let sec = document.getElementById("sec");
let newDate = new Date();
let secHand = newDate.getSeconds();
sec.textContent = secHand;
let minHand = newDate.getMinutes();
min.textContent = minHand;
let hrHand = newDate.getHours();
hr.textContent = hrHand;

let second = new Promise((resolve, reject) => {
  setInterval(() => {
    let newDate = new Date();
    let secHand = newDate.getSeconds();
    sec.textContent = secHand;
    resolve(secHand);
  }, 1000);
});

second
  .then((secHand) => {
    if (secHand === 0) {
      let newDate = new Date();
      let minHand = newDate.getMinutes();
      min.textContent = minHand;
      resolve(minHand); // Return the value
    }
  })
  .then((minHand) => {
    console.log(minHand);
    if (minHand === 0) { // Use strict equality (===)
      let newDate = new Date();
      let hrHand = newDate.getHours();
      hr.textContent = hrHand;
    }
  });
